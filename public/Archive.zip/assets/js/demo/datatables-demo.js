// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable({
      "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
      "iDisplayLength": 10
  });

  $('#dataTable1').DataTable({
      "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
      "iDisplayLength": 10
  });  

  $('#dataTable2').DataTable({
      "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
      "iDisplayLength": 10
  });
    
  $('#dataTable3').DataTable({
    "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
    "iDisplayLength": 10
    });  

    $('#dataTable4').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });  

    $('#dataTable5').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });  

    $('#dataTable6').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });  

    $('#dataTable8').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });  

    $('#dataTable11').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });
    
    $('#dataTable12').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });

    $('#dataTable13').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });

    $('#dataTable14').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });

    $('#dataTable15').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });
    $('#dataTable16').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });
    $('#dataTable17').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });
    $('#dataTable18').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });

    $('#dataTable20').DataTable({
        "aLengthMenu": [[50, 100, 200, -1], [50, 100, 200, "All"]],
        "iDisplayLength": 50
    });

    $('#dataTable21').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });  
    

    $('#dataTable22').DataTable({
        "aLengthMenu": [[10, 50, 75, -1], [10, 50, 75, "All"]],
        "iDisplayLength": 10
    });  
});
