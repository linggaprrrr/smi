<?= $this->extend('admin/layout/content') ?>

<?= $this->section('content') ?>
<div class="row">
    
</div>
<?= $this->endSection() ?>